#include <iostream.h>
#include <cstdlib>
#include <math.h>
/*
Student: Joel Kurian
Period: 6
Class: C++/JAVA A
Teacher: Mrs.Snelson
School: Randolph High School
Compiler: Dev-C++
Chapter: 5
Page 153 # 3
*/
int main()
{
    int num = 0;
    while (num <= 20) // loops until num is less than or equal to 20
    {
          cout << num << "  "; // displays num and adds spaces after it
          num++; // adds one to num
    }
    cout << '\n'; // new line
    system("PAUSE");
    return 0;
}
